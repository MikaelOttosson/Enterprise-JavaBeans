/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2609client;

import javax.ejb.EJB;
import t2609.CalculatorRemote;

/**
 *
 * @author Administrator
 */
public class Main {

    @EJB static CalculatorRemote calculator;
    
    public static void main(String[] args) {
        int result = calculator.add(42,54);
        System.out.println("42 + 54 =" + result);
    }
    
}
