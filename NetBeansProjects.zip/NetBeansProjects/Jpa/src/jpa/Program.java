package jpa;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Program {

    public static void main(String[] args) {
        
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("JpaPU");
        EntityManager em = emf.createEntityManager();

        try {
            Query q =  em.createNamedQuery("Product.findAll");
            
            List<Product> products = q.getResultList();
            for(Product p : products) {
                System.out.println(p);
                
                //step 11
                for(PurchaseOrder po: p.getPurchaseOrderCollection()) {
                    System.out.println(" -> " + po.toString());
                }
            }
            Query q2 = em.createNamedQuery("Product.findByProductId");
            q2.setParameter("productId", 978493);
            Product p = (Product) q2.getSingleResult();
            System.out.println(p);
            
        } finally {
            em.close();
        }
    }

}
