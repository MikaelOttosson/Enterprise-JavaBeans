package t2609;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Products")
public class Product implements Serializable{
    
    @Id
    @GeneratedValue
    private int productId;

    public Product() {
    }

    
    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getInStock() {
        return inStock;
    }

    public void setInStock(int inStock) {
        this.inStock = inStock;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }
    private String name;
    private int inStock;
    private double unitPrice;

    public Product(int id, String name, int inStock, double unitPrice) {
        this.productId = id;
        this.name = name;
        this.inStock = inStock;
        this.unitPrice = unitPrice;
                 
    }

    public void adjustStockLevel(int delta) {
        inStock += delta;
    }
  
}
