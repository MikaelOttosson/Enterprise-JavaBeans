package t2609;

import java.util.Map;

public interface ShoppingCart {
    void addItem(int productId, int quantity);
    Map<Integer,Integer> getItems();
    void checkout();
}
