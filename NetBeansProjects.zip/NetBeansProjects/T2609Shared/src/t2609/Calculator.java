/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2609;

/**
 *
 * @author Administrator
 */
public interface Calculator {
    int add(int a, int b);
    int substract(int a, int b);
    int multiply(int a, int b);
    double divide(int a, int b);
}
