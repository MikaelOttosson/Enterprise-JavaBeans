
package t2609;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;


public class TimerInterceptor {
    
    @AroundInvoke
    public Object intercept(InvocationContext ctx) throws Exception {
        long start = System.nanoTime();
        Object result = ctx.proceed();
        long duration = System.nanoTime() - start;
        System.out.println("Intercepted " + ctx.getMethod() + ", ticks: " + duration);
        return result;
    }
}
