/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2609;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJB;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;

/**
 *
 * @author Administrator
 */
@MessageDriven(activationConfig = {
    @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "orders"),
    @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue")
})
public class OrderProcessing implements MessageListener {
    
    //EX 8 - Step 6
    @EJB ProductsLocal products;
    
    
    public OrderProcessing() {
    }
    
    @Override
    public void onMessage(Message message) {
        try {
            Order order = (Order) message.getBody(Order.class);
            System.out.println("Processing order: " + order.getOrderDetails());
            if (products.adjustStockLevels(order)) System.out.println("OK!");
            else System.out.println("REJECTED!");
                
        } catch (JMSException ex) {
            Logger.getLogger(OrderProcessing.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
