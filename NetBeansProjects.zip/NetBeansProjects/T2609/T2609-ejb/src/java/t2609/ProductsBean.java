/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2609;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Singleton;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerConfig;
import javax.ejb.TimerService;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Singleton
public class ProductsBean implements ProductsRemote, ProductsLocal {

    @PersistenceContext EntityManager em;
    @Resource SessionContext session;
    
    private List<Product> products = new ArrayList<>();

    public ProductsBean() {
        products.add(new Product(1, "Ost", 10, 42));
        products.add(new Product(2, "Smör", 0, 52));
        products.add(new Product(3, "Bröd", 4, 22));
        products.add(new Product(4, "Ägg", 4, 32));
    }

    @Override
    public List<Product> getProducts() {
        return products;
    }

    @Override
    public boolean adjustStockLevels(Order order) {
        return true;
    }

    @Override
    public int addProduct(String name, int price, int quantity) {
        Product p = new Product(0, name, quantity, price);
        em.persist(p);
        products.add(p);
        return p.getProductId();
    }

    @Override
    public void scheduleRestock(int productId, int quantity, Date restockAt) {
        TimerService timerService = session.getTimerService();
        
        TimerConfig config = new TimerConfig();
        config.setInfo(quantity + "," + productId);
        timerService.createSingleActionTimer(restockAt, config);
    }
    
    @Timeout
    public void restock(Timer timer) {
        System.out.println("Restock called by timer: " + timer.getInfo());
    }
}
