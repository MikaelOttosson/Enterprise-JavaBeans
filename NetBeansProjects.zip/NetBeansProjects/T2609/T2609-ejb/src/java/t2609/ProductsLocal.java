/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2609;

import java.util.Date;
import java.util.Map;
import javax.ejb.Local;

/**
 *
 * @author Administrator
 */
@Local
public interface ProductsLocal {
    public boolean adjustStockLevels(Order order);

    void scheduleRestock(int productId, int quantity, Date restockAt);
}
