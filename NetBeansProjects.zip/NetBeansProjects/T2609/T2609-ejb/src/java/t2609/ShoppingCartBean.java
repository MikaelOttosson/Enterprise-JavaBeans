package t2609;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;
import javax.annotation.Resource;
import javax.ejb.Remove;
import javax.ejb.Stateful;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.Queue;

@Stateful
public class ShoppingCartBean implements ShoppingCartRemote, ShoppingCartLocal, Serializable {
    
    @Resource(mappedName = "orders")
    private Queue orders;
    
    @Inject
    @JMSConnectionFactory("java:comp/DefaultJMSConnectionFactory")
    private JMSContext context;

    Map<Integer,Integer> items = new TreeMap<>();
    
    @Override
    public void addItem(int productId, int quantity) {
        if (!items.containsKey(productId)) items.put(productId, 0);
        int newQuantity = items.get(productId) + quantity;
        items.put(productId, newQuantity);
    }

    @Override
    public Map<Integer, Integer> getItems() {
        return items;
    }

    @Override
    @Remove
    public void checkout() {
        
        Order order = new Order();
        order.setOrderDetails("Order created " + new Date());
        sendJMSMessageToOrders(order);
        items.clear();
        
        
    }

    private void sendJMSMessageToOrders(Order order) {
        context.createProducer().send(orders, order);
    }
}
