/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t2609;

import javax.annotation.security.RolesAllowed;
import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
@Interceptors({TimerInterceptor.class})
@Local(CalculatorLocal.class)
@Remote(CalculatorRemote.class)
@Stateless

public class CalculatorBean implements CalculatorRemote, CalculatorLocal {

    @Override
    public int add(int a, int b) {
        System.out.println("Calling add()");
        return a + b;
    }

    
    @Override
    public int substract(int a, int b) {
        System.out.println("Calling substract()");
        return a - b;
    }

    @Override
    public int multiply(int a, int b) {
        System.out.println("Calling multiply");
        return a * b;
    }

    @RolesAllowed({"role1"})
    @Override
    public double divide(int a, int b) {
        System.out.println("Calling divide");
        return a / (double) b;
    }
}
