/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package standaloneclient;

import java.util.Map;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import t2609.CalculatorRemote;
import t2609.Product;
import t2609.ProductsRemote;
import t2609.ShoppingCartRemote;

/**
 *
 * @author Administrator
 */
public class StandaloneClient {

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws NamingException {
        
        //Exercise 3
        InitialContext ctx = new InitialContext();
        String name = CalculatorRemote.class.getName();
        CalculatorRemote calculator = (CalculatorRemote) ctx.lookup(name);
        
        double result = calculator.divide(20, 19);
        System.out.println("20*19=" + result);
        
        //Exercise 4 step 4
        ProductsRemote products = (ProductsRemote) ctx.lookup(ProductsRemote.class.getName());
        
        products.addProduct("Bananas", 100, 10);
        
        for(Product p : products.getProducts()) {
            System.out.println("Product: " + p.getProductId() + ", unitPrice: " + p.getUnitPrice());
                    
        }        
        
        
        //Exercise 5 step 6
        ShoppingCartRemote cart = (ShoppingCartRemote) ctx.lookup(ShoppingCartRemote.class.getName());
        cart.addItem(1,10);
        cart.addItem(1,3);
        cart.addItem(2,5);
        Map<Integer,Integer> items = cart.getItems();
        for(Integer i : items.keySet()) {
            int quantity = items.get(i);
            System.out.println("id: " + i + ", q: " + quantity);
        }
        cart.checkout();
        
        //should throw an exception because checkout() terminates session bean
        cart.addItem(1, 4);
    }
    
}
